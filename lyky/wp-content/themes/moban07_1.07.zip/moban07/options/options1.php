  <div class="modle">
<p>这款主题有一个付费版本，代码重新编写，更加精简，对SEO支持度更好，速度更快，详情请见主题介绍和主题演示</p>

<a target="_blank" href="http://www.themepark.com.cn/lbqysybwordpresszt.html"> http://www.themepark.com.cn/lbqysybwordpresszt.html</a></b>
<br /><br /><br />
付费版演示：<br /><br /><br /><a target="_blank" href="http://www.themepark.com.cn/demo/?themedemo=bluepark"> http://www.themepark.com.cn/demo/?themedemo=bluepark</a></b>

</div> 
  
   <div class="up">
                 
                     
                    <b class="bt">ICO图标上传</b>
                    <input type="text" size="80"  name="ico" id="ico" value="<?php echo get_option('mytheme_ico'); ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>   
                    <p><a href="http://www.themepark.com.cn/icotpssmrhzzicowj.html" target="_blank">ico是什么？ico图片制作教程</a></p>
                </div>       
                
                
                
				<div class="up">
                  <b class="bt">LOGO的图片地址</b>
                     <div class="yulan">
                  <?php if (get_option('mytheme_logo')!=""): ?>
                    <img title="logo预览" src="<?php echo get_option('mytheme_logo'); ?>"alt="logo预览" /> 
                 <?php else : ?>
                    <img title="上传图片，这里可以预览" src="<?php bloginfo('template_url'); ?>/images/xuanxiang/yulan2.gif"alt="上传图片，这里可以预览"/>
                    <?php endif; ?>  
                    
                     </div>
                    <input type="text" size="80"  name="logo" id="logo" value="<?php echo get_option('mytheme_logo'); ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>   
                    <p>请上传logo图片，图片格式为PNG,或者带有浅色底色的jpg和gif均可（ 高度为100px，宽度自定，宽度请勿上传太大，以防止导航位置不够。）</p>
                </div>    
                
              <div class="xiaot">    
               
                <p>视频[视频请复制优酷等通用视频代码粘贴在此，此处也支持html代码]</p>
            <textarea name="spbf" cols="86" rows="4" id="spbf"><?php echo stripslashes(get_option('mytheme_spbf')); ?></textarea>     	
                    
                 </div> 
                 
                 
                  <div class="xiaot">
                      <b class="bt">联系资料</b><br />
                      <p>填写一些必要的联系资料，他们会显示在网页的顶部和底部，另外，你可以单独设定一个页面为“联系我们”。</p>
                  
            <p> <label  for="dh_1">电话1：</label> 
           <input type="text" size="60"  name="dh_1" id="dh_1" value="<?php echo get_option('mytheme_dh_1');  ?>"/  />
            </p>
                     
            <p> <label  for="dh_2">电话2：</label> 
           <input type="text" size="60"  name="dh_2" id="dh_2" value="<?php echo get_option('mytheme_dh_2');  ?>"/  />
            </p>
                     
            <p> <label  for="dh_3">电话3：</label> 
           <input type="text" size="60"  name="dh_3" id="dh_3" value="<?php echo get_option('mytheme_dh_3');  ?>"/  />
            </p>
            
                  <p> <label  for="qq_1">QQ1：</label> 
           <input type="text" size="60"  name="qq_1" id="qq_1" value="<?php echo get_option('mytheme_qq_1');  ?>"/  />
            </p>
            
                 <p> <label  for="qq_2">QQ2：</label> 
           <input type="text" size="60"  name="qq_2" id="qq_2" value="<?php echo get_option('mytheme_qq_2');  ?>"/  />
            </p>
                     
                     
                          <p> <label  for="qq_3">QQ3：</label> 
           <input type="text" size="60"  name="qq_3" id="qq_3" value="<?php echo get_option('mytheme_qq_3');  ?>"/  />
            </p>
                     
                     
           
            
               <p> <label  for="em_1">电子邮箱：</label> 
           <input type="text" size="60"  name="em_1" id="em_1" value="<?php echo get_option('mytheme_em_1');  ?>"/  />
            </p>
            
               <p> <label  for="cz_1">传真：</label> 
           <input type="text" size="60"  name="cz_1" id="cz_1" value="<?php echo get_option('mytheme_cz_1');  ?>"/  />
            </p>
            
              <p> <label  for="case2_bt">联系地址：</label> 
           <input type="text" size="60"  name="dz_1" id="dz_1" value="<?php echo get_option('mytheme_dz_1');  ?>"/  />
            </p>
            
             <p> <label  for="case2_bt">路线：</label> 
           <input type="text" size="60"  name="lx_1" id="lx_1" value="<?php echo get_option('mytheme_lx_1');  ?>"/  />
            </p>
            
              <p> <label  for="case2_bt">ICP备案号：</label> 
           <input type="text" size="60"  name="icp_b" id="icp_b" value="<?php echo get_option('mytheme_icp_b');  ?>"/  />
            </p>
                     <p> <a>WEB主题公园的主题下方会有一个“技术支持：WEB主题公园”的信息，免费版的用户请尊重我们的原创，尽量予以保留，我们将非常感谢，付费版用户可以选择不显示这个版权</a>  </p>
     
</div>  
                    
                
            