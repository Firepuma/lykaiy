 <div class="xiaot">
<b class="bt">多语言翻译</b><br />
                      <p>这里你可以自己把下面的一些固定的词语翻译成你想要的语言，或者改变他们，成为你想要的词语，关于多语言站点的建立，请访问教程：<a>使用WordPress多站点建立多语言网站</a></p>
                      </div>

<div class="modle">
<b>多语言翻译只有付费版可用，具体请查看付费版介绍：<br /><br /><br />

<a target="_blank" href="http://www.themepark.com.cn/lbqysybwordpresszt.html"> http://www.themepark.com.cn/lbqysybwordpresszt.html</a></b>
<br /><br /><br />
付费版演示：<br /><br /><br /><a target="_blank" href="http://www.themepark.com.cn/demo/?themedemo=bluepark"> http://www.themepark.com.cn/demo/?themedemo=bluepark</a></b>

</div> 