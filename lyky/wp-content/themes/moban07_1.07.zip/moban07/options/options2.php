                                         
            <div class="xiaot">
                      <b class="bt">焦点图1</b><br />
                      <div class="yulan2">
                          <?php 
						  $jdt1= get_option('mytheme_jdt1');
						  $jdxt1= get_option('mytheme_jdxt1');
						  $jdtbt1= get_option('mytheme_jdtbt1');
						  $jdtlj1= get_option('mytheme_jdtlj1');
						  $jdtjj1= get_option('mytheme_jdtjj1');
                        
						  ?>
                        
                     </div>
                     <div class="up" >

                    <label  for="jdt1">请上传大图片（1920 X 443尺寸图片）</label>
                    <input type="text" size="40"  name="jdt1" id="jdt1" value="<?php echo $jdt1; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div>
                       <div class="up" >

                     <label  for="jdxt1">请上传小图图片（宽162px 高99)  </label>
                    <input type="text" size="40"  name="jdxt1" id="jdxt1" value="<?php echo $jdxt1; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div> 
                   
                       <label  for="jdtbt1">"焦点图标题："</label>        
                       <input type="text" size="20"  name="jdtbt1" id="jdtbt1" value="<?php echo $jdtbt1; ?>"/> <br />
                       <label  for="jdtbt1">"焦点图简介："</label>        
                       <textarea name="jdtjj1" id="jdtjj1" rows="2" cols="70"><?php echo get_option('mytheme_jdtjj1'); ?></textarea>
                       
                             
                     <p>请填写链接，如果不填写，则为空连接</p>
                      <input type="text" size="60"  name="jdtlj1" id="jdtlj1" value="<?php echo $jdtlj1; ?>" />

                   </div>
            
             <div class="xiaot">
                      <b class="bt">焦点图2</b><br />
                      <div class="yulan2">
                          <?php 
						  $jdt2= get_option('mytheme_jdt2');
						  $jdxt2= get_option('mytheme_jdxt2');
						  $jdtbt2= get_option('mytheme_jdtbt2');
						  $jdtlj2= get_option('mytheme_jdtlj2');
						  $jdtjj2= get_option('mytheme_jdtjj2');
                        
						  ?>
                        
                     </div>
                     <div class="up" >

                    <label  for="jdt2">请上传大图片（1920 X 443尺寸图片）</label>
                    <input type="text" size="40"  name="jdt2" id="jdt2" value="<?php echo $jdt2; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div>
                       <div class="up" >

                     <label  for="jdxt2">请上传小图图片（宽162px 高99)  </label>
                    <input type="text" size="40"  name="jdxt2" id="jdxt2" value="<?php echo $jdxt2; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div> 
                   
                       <label  for="jdtbt2">"焦点图标题："</label>        
                       <input type="text" size="20"  name="jdtbt2" id="jdtbt2" value="<?php echo $jdtbt2; ?>"/> <br />
                       <label  for="jdtbt2">"焦点图简介："</label>        
                       <textarea name="jdtjj2" id="jdtjj2" rows="2" cols="70"><?php echo get_option('mytheme_jdtjj2'); ?></textarea>
                       
                             
                     <p>请填写链接，如果不填写，则为空连接</p>
                      <input type="text" size="60"  name="jdtlj2" id="jdtlj2" value="<?php echo $jdtlj2; ?>" />

                   </div>
            
            
              <div class="xiaot">
                      <b class="bt">焦点图3</b><br />
                      <div class="yulan2">
                          <?php 
						  $jdt3= get_option('mytheme_jdt3');
						  $jdxt3= get_option('mytheme_jdxt3');
						  $jdtbt3= get_option('mytheme_jdtbt3');
						  $jdtlj3= get_option('mytheme_jdtlj3');
						  $jdtjj3= get_option('mytheme_jdtjj3');
                        
						  ?>
                        
                     </div>
                     <div class="up" >

                    <label  for="jdt3">请上传大图片（1920 X 443尺寸图片）</label>
                    <input type="text" size="40"  name="jdt3" id="jdt3" value="<?php echo $jdt3; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div>
                       <div class="up" >

                     <label  for="jdxt3">请上传小图图片（宽162px 高99)  </label>
                    <input type="text" size="40"  name="jdxt3" id="jdxt3" value="<?php echo $jdxt3; ?>"/>   
                    <input type="button" name="upload_button" value="上传" id="upbottom"/>  
                      </div> 
                   
                       <label  for="jdtbt3">"焦点图标题："</label>        
                       <input type="text" size="30"  name="jdtbt3" id="jdtbt3" value="<?php echo $jdtbt3; ?>"/> <br />
                       <label  for="jdtbt3">"焦点图简介："</label>        
                       <textarea name="jdtjj3" id="jdtjj3" rows="2" cols="70"><?php echo get_option('mytheme_jdtjj3'); ?></textarea>
                       
                             
                     <p>请填写链接，如果不填写，则为空连接</p>
                      <input type="text" size="60"  name="jdtlj3" id="jdtlj3" value="<?php echo $jdtlj3; ?>" />

                   </div>
            
           
                   
                     