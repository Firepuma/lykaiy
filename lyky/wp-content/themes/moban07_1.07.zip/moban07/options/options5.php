 <div class="xiaot">
<b class="bt">移动版本兼容</b><br />
                      <p>免费版本不支持移动化设备，付费版本内置移动主题，完美兼容移动设备。</p>
                      </div>

<div class="modle">
<p>移动主题是按照移动设备而开发的，所有的效果都是点击（touch），而非鼠标经过（hover） 。<br />

经过测试，在IOS7 和安卓4.42版本中表现非常流畅，在微信中打开表现尤为突出，如果你在做微信和微博的推广，那么就可以再你的公众账号上直接发送你的官网地址！<br />

移动主题不需要设置较多内容，只需要你加入一些适应移动的焦点图<br />
现在在文章编辑中“焦点图设置” 多了一个“手机网站焦点图”，请在文章中的添加媒体中上传一张1024 *594的图片，讲图片的链接复制出来，粘贴在该选项即可！。 </p>

<a target="_blank" href="http://www.themepark.com.cn/lbqysybwordpresszt.html"> http://www.themepark.com.cn/lbqysybwordpresszt.html</a></b>
<br /><br /><br />
付费版演示：<br /><br /><br /><a target="_blank" href="http://www.themepark.com.cn/demo/?themedemo=bluepark"> http://www.themepark.com.cn/demo/?themedemo=bluepark</a></b>

</div> 